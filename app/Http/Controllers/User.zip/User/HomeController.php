<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\movie;
use App\Models\cast;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function index()
    {
        $movies= movie::all();
        return view('user/movies',compact('movies'));

    }
//    public function tag(tag $tag)
//    {
//        $posts = $tag->posts();
//        return view('user/blog',compact('posts'));
//    }
//    public function category(category $category)
//    {
//        $posts = $category->posts();
//        return view('user/blog',compact('posts'));
//    }
}
